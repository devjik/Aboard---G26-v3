# Onukpa Express Ride

Student-focused intercity booking for Ghana. Canonical app:

- **Frontend:** `wkm-transport/frontend` (React + Vite)
- **API:** `wkm-transport/backend/src` (Express + TypeScript + Prisma + PostgreSQL)
- **Payments:** Hubtel Unified Checkout (mockable in development)

The vanilla `landing-page/`, HTML `dashboard/`, and legacy MySQL `server.js` are **not** the supported stack.

## Quick start

```bash
# 1. Database
cd wkm-transport
docker compose up -d postgres redis

# 2. API
cd backend
cp .env.example .env
npm install
npx prisma generate
npx prisma db push
npm run seed
npm run dev          # http://localhost:5000

# 3. Web
cd ../frontend
npm install
npm run dev          # http://localhost:3000
```

Dev admin (after seed, non-production):

- Email: `admin@onukpaexpress.com`
- Password: `OnukpaAdmin1` (or `ADMIN_BOOTSTRAP_PASSWORD` from `.env`)

Set `HUBTEL_MOCK=true` in `backend/.env` to complete checkout without live charges. Point Hubtel keys and `HUBTEL_MOCK=false` when you go live.

## API

- Base: `http://localhost:5000/api/v1`
- Health: `GET /health`
- Docs: `http://localhost:5000/api/v1/docs`

Guest booking is supported: `POST /bookings` then `POST /payments/init`. Amount is always taken from the database.

## Security notes

Never commit `.env`. Rotate Hubtel keys if they ever leaked. Default JWT secrets are rejected in production.
