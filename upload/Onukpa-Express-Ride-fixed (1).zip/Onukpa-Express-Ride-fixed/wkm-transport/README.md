# Onukpa Express Ride

Premium student transport booking for Ghana.

## Canonical stack

| Piece | Path | Run |
|---|---|---|
| Web | `frontend/` | `npm run dev` (Vite, port 3000) |
| API | `backend/src/` | `npm run dev` (Express, port 5000) |
| DB | Postgres 16 | `docker compose up -d` |
| Pay | Hubtel | `HUBTEL_MOCK=true` locally |

Do **not** start `backend/server.js` (legacy MySQL). `npm start` / `npm run dev` in `backend/` use TypeScript.

## Setup

1. Copy `backend/.env.example` → `backend/.env` and set `JWT_SECRET` (`openssl rand -base64 48`).
2. `docker compose up -d`
3. `cd backend && npm install && npx prisma generate && npx prisma db push && npm run seed && npm run dev`
4. `cd frontend && npm install && npm run dev`

Frontend talks to `VITE_API_URL` (default `http://localhost:5000/api/v1`).

## Booking flow

1. Student picks a **future** trip from `GET /routes`
2. `POST /bookings` with name, Ghana phone, seat count (auth optional)
3. `POST /payments/init` — amount comes from the booking row
4. Hubtel checkout (or mock redirect)
5. Webhook `POST /api/v1/webhooks/hubtel` confirms payment

## Admin

Sign in at `/admin/login` with a user whose `role` is `ADMIN`. Seed creates `admin@onukpaexpress.com`.

## Tests

```bash
cd backend && npm test
```
