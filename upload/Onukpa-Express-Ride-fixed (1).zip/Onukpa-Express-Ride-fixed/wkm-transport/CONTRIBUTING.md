# Contributing

1. Use the TypeScript API (`backend/src`) and React app (`frontend`). Do not add features to the legacy MySQL `server.js` or the vanilla `landing-page`.
2. Keep secrets out of git. Put values in `backend/.env` (see `.env.example`).
3. Amounts charged to Hubtel must come from the database, never from the client.
4. Run `cd backend && npm test` and `npx tsc --noEmit` before opening a PR.
