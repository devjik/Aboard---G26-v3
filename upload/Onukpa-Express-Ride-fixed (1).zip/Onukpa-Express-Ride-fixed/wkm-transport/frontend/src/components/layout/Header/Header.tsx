import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { ROUTES } from '@/config/routes';
import { useAuthStore } from '@/store/auth.store';
import { ThemeSwitcher } from '@/components/common/ThemeSwitcher/ThemeSwitcher';
import { Logo } from '@/components/common/Logo/Logo';
import { MagneticWrap } from '@/components/animations/MagneticWrap';
import styles from './Header.module.css';

const NAV_LINKS = [
  { name: 'Home', path: ROUTES.HOME },
  { name: 'About', path: ROUTES.ABOUT },
  { name: 'Book a Ride', path: ROUTES.BOOK_RIDE },
  { name: 'Routes', path: ROUTES.ROUTES },
  { name: 'Pricing', path: ROUTES.PRICING },
  { name: 'Contact', path: ROUTES.CONTACT },
];

export const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { user, isAuthenticated, logout } = useAuthStore();
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    document.body.style.overflow = isMenuOpen ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [isMenuOpen]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setIsMenuOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''} ${isMenuOpen ? styles.menuOpen : ''}`}>
      <div className={`container ${styles.inner}`}>
        <Link to={ROUTES.HOME} className={styles.logo} aria-label="Onukpa Express Ride home">
          <Logo size={42} />
        </Link>

        <nav className={styles.desktopNav} aria-label="Primary">
          {NAV_LINKS.map((l) => (
            <MagneticWrap key={l.path} strength={15}>
              <Link
                to={l.path}
                className={`${styles.navLink} ${location.pathname === l.path ? styles.active : ''}`}
                aria-current={location.pathname === l.path ? 'page' : undefined}
              >
                {l.name}
              </Link>
            </MagneticWrap>
          ))}
        </nav>

        <div className={styles.actions}>
          <ThemeSwitcher />
          {isAuthenticated ? (
            <>
              {user?.role === 'ADMIN' && (
                <MagneticWrap strength={10}>
                  <Link to={ROUTES.ADMIN_DASHBOARD} className={styles.ctaOutline}>
                    Dashboard
                  </Link>
                </MagneticWrap>
              )}
              <MagneticWrap strength={10}>
                <button type="button" className={styles.ctaOutline} onClick={logout}>
                  Log out
                </button>
              </MagneticWrap>
            </>
          ) : (
            <>
              <MagneticWrap strength={10}>
                <Link to={ROUTES.LOGIN} className={styles.ctaOutline}>
                  Sign in
                </Link>
              </MagneticWrap>
              <MagneticWrap strength={20}>
                <Link to={ROUTES.BOOK_RIDE} className={styles.ctaPrimary}>
                  Book now
                </Link>
              </MagneticWrap>
            </>
          )}
        </div>

        <div className={styles.mobileActions}>
          <ThemeSwitcher />
          <button
            type="button"
            className={styles.hamburger}
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label={isMenuOpen ? 'Close menu' : 'Open menu'}
            aria-expanded={isMenuOpen}
            aria-controls="mobile-nav"
          >
            {isMenuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {isMenuOpen && (
        <nav id="mobile-nav" className={styles.mobileDrawer} aria-label="Mobile">
          {NAV_LINKS.map((l) => (
            <Link
              key={l.path}
              to={l.path}
              className={`${styles.mobileLink} ${location.pathname === l.path ? styles.mobileActive : ''}`}
              aria-current={location.pathname === l.path ? 'page' : undefined}
            >
              {l.name}
            </Link>
          ))}
          <div className={styles.mobileDivider} />
          {isAuthenticated ? (
            <button type="button" className={styles.mobileCta} onClick={logout}>
              Log out
            </button>
          ) : (
            <>
              <Link to={ROUTES.LOGIN} className={styles.mobileLink}>
                Sign in
              </Link>
              <Link to={ROUTES.BOOK_RIDE} className={styles.mobileCta}>
                Book a ride
              </Link>
            </>
          )}
        </nav>
      )}
    </header>
  );
};
