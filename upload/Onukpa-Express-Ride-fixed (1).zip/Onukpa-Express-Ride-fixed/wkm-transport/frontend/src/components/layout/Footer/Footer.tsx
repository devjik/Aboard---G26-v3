import React from 'react';
import { Link } from 'react-router-dom';
import { MessageCircle, Phone, Mail } from 'lucide-react';
import { ROUTES } from '@/config/routes';
import { WHATSAPP_NUMBER } from '@/config/api.config';
import styles from './Footer.module.css';
import { Logo } from '@/components/common/Logo/Logo';

export const Footer: React.FC = () => {
  const wa = WHATSAPP_NUMBER;
  return (
    <footer className={styles.footer}>
      <div className={`container ${styles.inner}`}>
        <div className={styles.brand}>
          <Link to={ROUTES.HOME} className={styles.logo} aria-label="Onukpa Express Ride home">
            <Logo size={48} />
          </Link>
          <p>Safe, affordable transport connecting university students with cities across Ghana.</p>
        </div>

        <div className={styles.col}>
          <h4>Quick links</h4>
          <ul>
            <li><Link to={ROUTES.HOME}>Home</Link></li>
            <li><Link to={ROUTES.ABOUT}>About</Link></li>
            <li><Link to={ROUTES.ROUTES}>Routes</Link></li>
            <li><Link to={ROUTES.PRICING}>Pricing</Link></li>
            <li><Link to={ROUTES.CONTACT}>Contact</Link></li>
          </ul>
        </div>

        <div className={styles.col}>
          <h4>Popular corridors</h4>
          <ul>
            <li><Link to={ROUTES.BOOK_RIDE}>Accra → Kumasi</Link></li>
            <li><Link to={ROUTES.BOOK_RIDE}>Kumasi → Accra</Link></li>
            <li><Link to={ROUTES.BOOK_RIDE}>Legon → KNUST</Link></li>
            <li><Link to={ROUTES.BOOK_RIDE}>Accra → Cape Coast</Link></li>
            <li><Link to={ROUTES.BOOK_RIDE}>Accra → Takoradi</Link></li>
          </ul>
        </div>

        <div className={styles.col}>
          <h4>Get in touch</h4>
          <div className={styles.contacts}>
            {wa ? (
              <a href={`https://wa.me/${wa}`} target="_blank" rel="noopener noreferrer" className={styles.contactRow}>
                <MessageCircle size={16} /> WhatsApp
              </a>
            ) : null}
            {wa ? (
              <a href={`tel:+${wa}`} className={styles.contactRow}>
                <Phone size={16} /> +{wa}
              </a>
            ) : null}
            <a href="mailto:hello@onukpaexpress.com" className={styles.contactRow}>
              <Mail size={16} /> hello@onukpaexpress.com
            </a>
          </div>
          <Link to={ROUTES.BOOK_RIDE} className={styles.bookBtn}>
            Book a ride
          </Link>
        </div>
      </div>

      <div className={styles.bottom}>
        <div className="container">
          <span>© {new Date().getFullYear()} Onukpa Express Ride. All rights reserved.</span>
          <span>Built for Ghanaian students</span>
          <Link to={ROUTES.ADMIN_LOGIN} className={styles.adminLink}>
            Admin
          </Link>
        </div>
      </div>
    </footer>
  );
};
