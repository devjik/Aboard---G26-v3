import React from 'react';
import { Outlet } from 'react-router-dom';
import { Header } from './Header/Header';
import { Footer } from './Footer/Footer';
import { PageTransition } from '@/components/common/PageTransition/PageTransition';
import { ErrorBoundary } from '@/components/common/ErrorBoundary';
import styles from './MainLayout.module.css';

export const MainLayout: React.FC = () => {
  return (
    <div className={styles.page}>
      <a href="#main-content" className="skip-link">Skip to content</a>
      <Header />
      <main id="main-content" className={styles.mainContent} tabIndex={-1}>
        <ErrorBoundary>
          <PageTransition>
            <Outlet />
          </PageTransition>
        </ErrorBoundary>
      </main>
      <Footer />
    </div>
  );
};

export const DashboardLayout: React.FC = () => {
  return (
    <div className={styles.page}>
      <a href="#main-content" className="skip-link">Skip to content</a>
      <Header />
      <div className={`container ${styles.dashboardContainer}`}>
        <main id="main-content" className={styles.dashboardMain} tabIndex={-1}>
          <ErrorBoundary>
            <PageTransition>
              <Outlet />
            </PageTransition>
          </ErrorBoundary>
        </main>
      </div>
      <Footer />
    </div>
  );
};
