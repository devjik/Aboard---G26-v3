import React from 'react';

interface State {
  hasError: boolean;
}

export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: Error) {
    console.error('Page error:', error.message);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{ padding: '6rem 1.5rem', textAlign: 'center' }}>
          <h2>Something went wrong</h2>
          <p style={{ color: 'var(--color-text-muted)', margin: '0.75rem 0 1.5rem' }}>
            Refresh the page or go back home.
          </p>
          <button
            type="button"
            onClick={() => window.location.assign('/')}
            style={{
              minHeight: 44,
              padding: '0.65rem 1.4rem',
              borderRadius: 9999,
              background: 'var(--gradient-cta)',
              color: '#fff',
              fontWeight: 700,
            }}
          >
            Go home
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
