import React, { useState } from 'react';
import { Phone, Mail, MessageCircle, Send, CheckCircle } from 'lucide-react';
import { StitchConnector } from '@/components/common/StitchConnector/StitchConnector';
import { MagneticWrap } from '@/components/animations/MagneticWrap';
import { FloatingCharacter } from '@/components/animations/FloatingCharacter';
import { WHATSAPP_NUMBER } from '@/config/api.config';
import styles from './Contact.module.css';

import charWaving from '@/assets/images/characters/student-white-waving.png';

export const Contact: React.FC = () => {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', phone: '', message: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!WHATSAPP_NUMBER) {
      setSent(true);
      return;
    }
    const msg = encodeURIComponent(
      `Hi Onukpa Express Ride! My name is ${form.name} (${form.phone}${form.email ? `, ${form.email}` : ''}). ${form.message}`
    );
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${msg}`, '_blank', 'noopener,noreferrer');
    setSent(true);
  };

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <span className="badge badge-primary">Get in touch</span>
          <h1>
            We're here to <span className="text-gradient">help</span>
          </h1>
          <p>Have a question about booking, routes, or payments? We respond fast via WhatsApp.</p>
        </div>
      </section>

      <StitchConnector />

      <section className={styles.contentSection}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.info}>
              <h2>Contact information</h2>
              <p>Reach us through any of the channels below. WhatsApp is the fastest.</p>

              <div className={styles.contactCards}>
                <a
                  href={WHATSAPP_NUMBER ? `https://wa.me/${WHATSAPP_NUMBER}` : 'mailto:hello@onukpaexpress.com'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`card ${styles.contactCard} ${styles.waCard}`}
                >
                  <MessageCircle size={24} aria-hidden />
                  <div>
                    <strong>WhatsApp</strong>
                    <span>{WHATSAPP_NUMBER ? `+${WHATSAPP_NUMBER}` : 'Set VITE_WHATSAPP_NUMBER'} · Fastest response</span>
                  </div>
                </a>
                <a
                  href={WHATSAPP_NUMBER ? `tel:+${WHATSAPP_NUMBER}` : 'mailto:hello@onukpaexpress.com'}
                  className={`card ${styles.contactCard}`}
                >
                  <Phone size={24} aria-hidden />
                  <div>
                    <strong>Phone</strong>
                    <span>{WHATSAPP_NUMBER ? `+${WHATSAPP_NUMBER}` : 'hello@onukpaexpress.com'} · Mon–Sun, 6 AM–8 PM</span>
                  </div>
                </a>
                <a href="mailto:hello@onukpaexpress.com" className={`card ${styles.contactCard}`}>
                  <Mail size={24} aria-hidden />
                  <div>
                    <strong>Email</strong>
                    <span>hello@onukpaexpress.com</span>
                  </div>
                </a>
              </div>
            </div>

            <div className={`card ${styles.formCard}`}>
              {sent ? (
                <div className={styles.sentMsg}>
                  <CheckCircle size={48} className={styles.sentIcon} aria-hidden />
                  <h3>{WHATSAPP_NUMBER ? 'Opening WhatsApp…' : 'Message captured'}</h3>
                  <p>
                    {WHATSAPP_NUMBER
                      ? "We'll get back to you as soon as possible."
                      : 'WhatsApp is not configured yet. Email hello@onukpaexpress.com instead.'}
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className={styles.contactForm}>
                  <h3>
                    Send us a <span className="text-gradient">message</span>
                  </h3>
                  <div className={styles.formGrid}>
                    <div className="form-group">
                      <label className="form-label" htmlFor="contact-name">
                        Full name
                      </label>
                      <input
                        id="contact-name"
                        type="text"
                        className="form-input"
                        autoComplete="name"
                        placeholder="Ama Owusu"
                        value={form.name}
                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                        required
                      />
                    </div>
                    <div className="form-group">
                      <label className="form-label" htmlFor="contact-email">
                        Email
                      </label>
                      <input
                        id="contact-email"
                        type="email"
                        className="form-input"
                        autoComplete="email"
                        placeholder="ama@example.com"
                        value={form.email}
                        onChange={(e) => setForm({ ...form, email: e.target.value })}
                      />
                    </div>
                  </div>
                  <div className="form-group" style={{ marginTop: '1rem' }}>
                    <label className="form-label" htmlFor="contact-phone">
                      Phone number
                    </label>
                    <input
                      id="contact-phone"
                      type="tel"
                      className="form-input"
                      autoComplete="tel"
                      placeholder="055 XXX XXXX"
                      value={form.phone}
                      onChange={(e) => setForm({ ...form, phone: e.target.value })}
                      required
                    />
                  </div>
                  <div className="form-group" style={{ marginTop: '1rem' }}>
                    <label className="form-label" htmlFor="contact-message">
                      Message
                    </label>
                    <textarea
                      id="contact-message"
                      className="form-textarea"
                      rows={4}
                      placeholder="How can we help you?"
                      value={form.message}
                      onChange={(e) => setForm({ ...form, message: e.target.value })}
                      required
                    />
                  </div>
                  <MagneticWrap strength={15}>
                    <button type="submit" className={styles.submitBtn}>
                      <Send size={18} aria-hidden /> {WHATSAPP_NUMBER ? 'Send via WhatsApp' : 'Send message'}
                    </button>
                  </MagneticWrap>

                  <FloatingCharacter
                    src={charWaving}
                    alt=""
                    size={120}
                    bottom="-20px"
                    right="-30px"
                    delay={0.5}
                  />
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
