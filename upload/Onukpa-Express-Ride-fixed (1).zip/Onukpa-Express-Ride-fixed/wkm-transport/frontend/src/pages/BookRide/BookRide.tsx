import React, { useEffect, useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Bus, MapPin, User, ChevronRight, CheckCircle } from 'lucide-react';
import { StitchConnector } from '@/components/common/StitchConnector/StitchConnector';
import { Button } from '@/components/common/Button/Button';
import { useRouteStore } from '@/store/route.store';
import { bookingService } from '@/services/booking.service';
import { paymentService } from '@/services/payment.service';
import { formatCurrency, formatDate, formatTime } from '@/utils/formatters';
import styles from './BookRide.module.css';

interface BookingForm {
  routeId: string;
  seats: string;
  name: string;
  phone: string;
}

const STEPS = ['Trip details', 'Your info', 'Payment'] as const;

export const BookRide: React.FC = () => {
  const { routeId } = useParams();
  const { routes, isLoading, fetchRoutes, error: routesError } = useRouteStore();
  const [step, setStep] = useState(1);
  const [form, setForm] = useState<BookingForm>({ routeId: '', seats: '1', name: '', phone: '' });
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [confirmed, setConfirmed] = useState<{ ticket: string; reference?: string } | null>(null);

  useEffect(() => {
    fetchRoutes();
  }, [fetchRoutes]);

  useEffect(() => {
    if (routeId && routeId !== 'success' && routeId !== 'cancelled') {
      setForm((f) => ({ ...f, routeId }));
    }
  }, [routeId]);

  const trips = useMemo(
    () =>
      routes.filter(
        (r) =>
          r.status === 'ACTIVE' &&
          Number(r.availableSeats ?? 0) > 0 &&
          r.departureTime &&
          new Date(r.departureTime) > new Date()
      ),
    [routes]
  );

  const selected = trips.find((r) => String(r.id) === form.routeId);
  const seats = Math.max(1, parseInt(form.seats || '1', 10));
  const total = selected ? Number(selected.price) * seats : 0;
  const maxSeats = Math.min(10, Number(selected?.availableSeats ?? 5));

  const handleNext = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError(null);
    if (step < 3) {
      setStep(step + 1);
      return;
    }
    if (!selected) {
      setSubmitError('Please select a trip.');
      return;
    }
    setSubmitting(true);
    try {
      const booking = await bookingService.createBooking({
        routeId: String(selected.id),
        numberOfTickets: seats,
        passengerName: form.name,
        passengerPhone: form.phone,
      });
      const pay = await paymentService.initiatePayment({
        bookingId: booking.id,
        provider: 'hubtel',
      });
      if (pay.paymentUrl) {
        window.location.href = pay.paymentUrl;
        return;
      }
      setConfirmed({ ticket: booking.ticketNumber, reference: pay.reference });
    } catch (err: any) {
      setSubmitError(err.response?.data?.message || 'Could not complete booking. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  if (confirmed) {
    return (
      <div className={styles.page}>
        <div className={styles.successWrap}>
          <div className={`card ${styles.successCard}`}>
            <CheckCircle size={60} className={styles.successIcon} aria-hidden />
            <h2>Booking created</h2>
            <p>
              Your ticket is <strong>{confirmed.ticket}</strong>. Complete payment if you were not redirected.
            </p>
            <Button
              onClick={() => {
                setConfirmed(null);
                setStep(1);
                setForm({ routeId: '', seats: '1', name: '', phone: '' });
              }}
            >
              Make another booking
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <span className="badge badge-primary">Book a ride</span>
          <h1>
            Reserve your <span className="text-gradient">seat</span>
          </h1>
          <p>Live trips from the Onukpa timetable. Pay with Mobile Money via Hubtel.</p>
        </div>
      </section>

      <StitchConnector />

      <section className={styles.formSection}>
        <div className="container">
          <div className={styles.layout}>
            <div>
              <ol className={styles.steps} aria-label="Booking steps">
                {STEPS.map((label, i) => (
                  <li
                    key={label}
                    className={`${styles.stepItem} ${step > i + 1 ? styles.stepDone : ''} ${
                      step === i + 1 ? styles.stepActive : ''
                    }`}
                    aria-current={step === i + 1 ? 'step' : undefined}
                  >
                    <div className={styles.stepNum}>{step > i + 1 ? '✓' : i + 1}</div>
                    <span>{label}</span>
                    {i < 2 && <div className={styles.stepLine} aria-hidden />}
                  </li>
                ))}
              </ol>

              <form onSubmit={handleNext} className={`card ${styles.formCard}`}>
                {step === 1 && (
                  <div className={styles.formBody}>
                    <h3>
                      <MapPin size={18} aria-hidden /> Trip details
                    </h3>
                    {isLoading && <p>Loading trips…</p>}
                    {routesError && (
                      <p className={styles.errorBanner} role="alert">
                        {routesError}
                      </p>
                    )}
                    {!isLoading && trips.length === 0 && (
                      <p className={styles.hint}>
                        No upcoming trips are published yet. Ask an admin to run the database seed.
                      </p>
                    )}
                    <div className="form-group">
                      <label className="form-label" htmlFor="route">
                        Select trip *
                      </label>
                      <select
                        id="route"
                        className="form-select"
                        value={form.routeId}
                        onChange={(e) => setForm({ ...form, routeId: e.target.value })}
                        required
                      >
                        <option value="">Choose your trip…</option>
                        {trips.map((r) => (
                          <option key={String(r.id)} value={String(r.id)}>
                            {r.departure} → {r.destination} ·{' '}
                            {r.departureTime ? `${formatDate(r.departureTime)} ${formatTime(r.departureTime)}` : ''} ·{' '}
                            {formatCurrency(Number(r.price))} · {r.availableSeats} seats
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="form-group">
                      <label className="form-label" htmlFor="seats">
                        Number of seats *
                      </label>
                      <select
                        id="seats"
                        className="form-select"
                        value={form.seats}
                        onChange={(e) => setForm({ ...form, seats: e.target.value })}
                      >
                        {Array.from({ length: Math.max(1, maxSeats) }, (_, i) => i + 1).map((n) => (
                          <option key={n} value={n}>
                            {n} seat{n > 1 ? 's' : ''}
                          </option>
                        ))}
                      </select>
                    </div>
                    <Button type="submit" rightIcon={<ChevronRight size={16} />} disabled={!form.routeId}>
                      Continue
                    </Button>
                  </div>
                )}

                {step === 2 && (
                  <div className={styles.formBody}>
                    <h3>
                      <User size={18} aria-hidden /> Your information
                    </h3>
                    <div className="form-group">
                      <label className="form-label" htmlFor="name">
                        Full name *
                      </label>
                      <input
                        id="name"
                        className="form-input"
                        autoComplete="name"
                        placeholder="e.g. Ama Owusu"
                        value={form.name}
                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                        required
                      />
                    </div>
                    <div className="form-group">
                      <label className="form-label" htmlFor="phone">
                        Ghana mobile number *
                      </label>
                      <input
                        id="phone"
                        className="form-input"
                        type="tel"
                        inputMode="tel"
                        autoComplete="tel"
                        placeholder="e.g. 055 123 4567"
                        value={form.phone}
                        onChange={(e) => setForm({ ...form, phone: e.target.value })}
                        required
                      />
                    </div>
                    <p className={styles.hint}>Used for your ticket and Mobile Money checkout.</p>
                    <div className={styles.navRow}>
                      <Button type="button" variant="outline" onClick={() => setStep(1)}>
                        Back
                      </Button>
                      <Button
                        type="submit"
                        rightIcon={<ChevronRight size={16} />}
                        disabled={!form.name || !form.phone}
                      >
                        Continue
                      </Button>
                    </div>
                  </div>
                )}

                {step === 3 && (
                  <div className={styles.formBody}>
                    <h3>
                      <Bus size={18} aria-hidden /> Pay with Hubtel
                    </h3>
                    <p className={styles.hint}>
                      You will be redirected to Hubtel to pay with MTN MoMo, Telecel Cash, AirtelTigo Money, or card.
                      The amount is taken from the live timetable — not typed in the browser.
                    </p>
                    {submitError && (
                      <p className={styles.errorBanner} role="alert">
                        {submitError}
                      </p>
                    )}
                    <div className={styles.navRow}>
                      <Button type="button" variant="outline" onClick={() => setStep(2)}>
                        Back
                      </Button>
                      <Button type="submit" isLoading={submitting} disabled={submitting}>
                        {submitting ? 'Processing…' : `Pay ${formatCurrency(total)}`}
                      </Button>
                    </div>
                  </div>
                )}
              </form>
            </div>

            <aside>
              <div className={`card ${styles.summary}`}>
                <h3 className={styles.summaryTitle}>Booking summary</h3>
                {selected ? (
                  <>
                    <div className={styles.summaryRouteLabel}>
                      {selected.departure} → {selected.destination}
                    </div>
                    {selected.departureTime && (
                      <div className={styles.summaryRow}>
                        <span>Departs</span>
                        <strong>
                          {formatDate(selected.departureTime)} · {formatTime(selected.departureTime)}
                        </strong>
                      </div>
                    )}
                    <div className={styles.summaryRow}>
                      <span>Seats</span>
                      <strong>{form.seats}</strong>
                    </div>
                    <div className={styles.summaryRow}>
                      <span>Price/seat</span>
                      <strong>{formatCurrency(Number(selected.price))}</strong>
                    </div>
                    <div className={`${styles.summaryRow} ${styles.totalRow}`}>
                      <span>Total</span>
                      <strong>{formatCurrency(total)}</strong>
                    </div>
                  </>
                ) : (
                  <p className={styles.summaryEmpty}>Select a trip to see your booking summary.</p>
                )}
              </div>
            </aside>
          </div>
        </div>
      </section>
    </div>
  );
};
