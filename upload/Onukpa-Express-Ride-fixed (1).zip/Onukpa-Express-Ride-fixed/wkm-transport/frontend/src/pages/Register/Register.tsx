import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Eye, EyeOff } from 'lucide-react';
import { useAuthStore } from '@/store/auth.store';
import { ROUTES } from '@/config/routes';
import { authService } from '@/services/auth.service';
import styles from '../Admin/AdminLogin.module.css';
import { Logo } from '@/components/common/Logo/Logo';

export const Register: React.FC = () => {
  const [form, setForm] = useState({ firstName: '', lastName: '', email: '', phone: '', password: '' });
  const [showPw, setShowPw] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { setAuth } = useAuthStore();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);
    try {
      const { user, tokens } = await authService.register(form);
      setAuth(user, tokens);
      navigate(ROUTES.HOME);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Could not create account.');
    } finally {
      setIsLoading(false);
    }
  };

  const set = (key: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [key]: e.target.value }));

  return (
    <div className={`${styles.page} ${styles.authSolo}`}>
      <div className={styles.formPanel}>
        <div className={styles.logo}>
          <Logo size={40} />
        </div>
        <h1 className={styles.formTitle}>Create account</h1>
        <p className={styles.formSub}>Optional — you can also book as a guest</p>
        <form onSubmit={handleSubmit} className={styles.form}>
          <div className={styles.formGroup}>
            <label className={styles.label} htmlFor="firstName">
              First name
            </label>
            <input id="firstName" className={styles.input} autoComplete="given-name" value={form.firstName} onChange={set('firstName')} required />
          </div>
          <div className={styles.formGroup}>
            <label className={styles.label} htmlFor="lastName">
              Last name
            </label>
            <input id="lastName" className={styles.input} autoComplete="family-name" value={form.lastName} onChange={set('lastName')} required />
          </div>
          <div className={styles.formGroup}>
            <label className={styles.label} htmlFor="regEmail">
              Email
            </label>
            <input id="regEmail" className={styles.input} type="email" autoComplete="email" value={form.email} onChange={set('email')} required />
          </div>
          <div className={styles.formGroup}>
            <label className={styles.label} htmlFor="regPhone">
              Phone (optional)
            </label>
            <input id="regPhone" className={styles.input} type="tel" autoComplete="tel" value={form.phone} onChange={set('phone')} />
          </div>
          <div className={styles.formGroup}>
            <label className={styles.label} htmlFor="regPassword">
              Password (8+ chars, letter + number)
            </label>
            <div className={styles.inputWrapper}>
              <input
                id="regPassword"
                className={styles.input}
                type={showPw ? 'text' : 'password'}
                value={form.password}
                onChange={set('password')}
                required
                minLength={8}
                autoComplete="new-password"
              />
              <button
                type="button"
                className={styles.eyeBtn}
                onClick={() => setShowPw((v) => !v)}
                aria-label={showPw ? 'Hide password' : 'Show password'}
              >
                {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>
          {error && (
            <div className={styles.errorBanner} role="alert">
              {error}
            </div>
          )}
          <button type="submit" className={styles.submitBtn} disabled={isLoading} aria-busy={isLoading}>
            {isLoading ? 'Creating…' : 'Create account'}
          </button>
        </form>
        <p className={styles.formSub}>
          Already registered? <Link to={ROUTES.LOGIN}>Sign in</Link>
          {' · '}
          <Link to={ROUTES.BOOK_RIDE}>Book as a guest</Link>
        </p>
      </div>
    </div>
  );
};
