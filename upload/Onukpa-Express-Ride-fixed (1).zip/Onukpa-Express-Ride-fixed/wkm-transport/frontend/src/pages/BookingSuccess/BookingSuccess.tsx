import React, { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { CheckCircle, Home, Printer } from 'lucide-react';
import { Button } from '@/components/common/Button/Button';
import { ROUTES } from '@/config/routes';
import { paymentService } from '@/services/payment.service';
import styles from './BookingSuccess.module.css';

export const BookingSuccess: React.FC = () => {
  const [searchParams] = useSearchParams();
  const ticketNumber = searchParams.get('ticket') || '';
  const reference = searchParams.get('reference') || '';
  const [status, setStatus] = useState<string>(reference ? 'Confirming payment…' : 'Booking recorded');
  const [ticket, setTicket] = useState(ticketNumber);

  useEffect(() => {
    if (!reference) return;
    paymentService
      .verifyPayment(reference)
      .then((payment) => {
        setStatus(payment.status === 'SUCCESS' ? 'Payment confirmed' : `Payment ${payment.status.toLowerCase()}`);
        const t = (payment as any).booking?.ticketNumber;
        if (t) setTicket(t);
      })
      .catch(() => setStatus('We could not confirm payment yet. Keep your reference and contact support if charged.'));
  }, [reference]);

  return (
    <div className={`container ${styles.page}`}>
      <div className={styles.card}>
        <div className={styles.iconWrapper}>
          <CheckCircle size={56} />
        </div>

        <h1 className={styles.title}>{status}</h1>
        <p className={styles.subtitle}>
          Present your ticket at the boarding point at least 15 minutes before departure.
        </p>

        {(ticket || reference) && (
          <div className={styles.ticketBox}>
            <span className={styles.ticketLabel}>{ticket ? 'Ticket Number' : 'Payment reference'}</span>
            <span className={styles.ticketNumber}>{ticket || reference}</span>
          </div>
        )}

        <div className={styles.actions}>
          <Link to={ROUTES.HOME}>
            <Button variant="primary" size="lg" leftIcon={<Home size={18} />}>
              Go Home
            </Button>
          </Link>
          <Button variant="outline" size="lg" leftIcon={<Printer size={18} />} onClick={() => window.print()}>
            Print Ticket
          </Button>
        </div>
      </div>
    </div>
  );
};
