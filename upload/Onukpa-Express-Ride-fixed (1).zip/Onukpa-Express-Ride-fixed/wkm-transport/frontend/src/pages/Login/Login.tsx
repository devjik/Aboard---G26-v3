import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Lock, Mail, Eye, EyeOff } from 'lucide-react';
import { useAuthStore } from '@/store/auth.store';
import { ROUTES } from '@/config/routes';
import { authService } from '@/services/auth.service';
import styles from '../Admin/AdminLogin.module.css';
import { Logo } from '@/components/common/Logo/Logo';

export const Login: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { setAuth } = useAuthStore();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);
    try {
      const { user, tokens } = await authService.login({ email, password });
      setAuth(user, tokens);
      navigate(user.role === 'ADMIN' ? ROUTES.ADMIN_DASHBOARD : ROUTES.HOME);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Invalid credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className={`${styles.page} ${styles.authSolo}`}>
      <div className={styles.formPanel}>
        <div className={styles.logo}>
          <Logo size={40} />
        </div>
        <h1 className={styles.formTitle}>Sign in</h1>
        <p className={styles.formSub}>Access your Onukpa Express Ride account</p>
        <form onSubmit={handleSubmit} className={styles.form}>
          <div className={styles.formGroup}>
            <label className={styles.label} htmlFor="email">
              Email
            </label>
            <div className={styles.inputWrapper}>
              <Mail size={16} className={styles.inputIcon} aria-hidden />
              <input
                id="email"
                type="email"
                className={styles.input}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                autoComplete="username"
              />
            </div>
          </div>
          <div className={styles.formGroup}>
            <label className={styles.label} htmlFor="password">
              Password
            </label>
            <div className={styles.inputWrapper}>
              <Lock size={16} className={styles.inputIcon} aria-hidden />
              <input
                id="password"
                type={showPw ? 'text' : 'password'}
                className={styles.input}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                autoComplete="current-password"
              />
              <button
                type="button"
                className={styles.eyeBtn}
                onClick={() => setShowPw((v) => !v)}
                aria-label={showPw ? 'Hide password' : 'Show password'}
              >
                {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>
          {error && (
            <div className={styles.errorBanner} role="alert">
              {error}
            </div>
          )}
          <button type="submit" className={styles.submitBtn} disabled={isLoading} aria-busy={isLoading}>
            {isLoading ? 'Signing in…' : 'Sign in'}
          </button>
        </form>
        <p className={styles.formSub}>
          No account? <Link to={ROUTES.REGISTER}>Create one</Link>
          {' · '}
          <Link to={ROUTES.BOOK_RIDE}>Book as a guest</Link>
        </p>
      </div>
    </div>
  );
};
