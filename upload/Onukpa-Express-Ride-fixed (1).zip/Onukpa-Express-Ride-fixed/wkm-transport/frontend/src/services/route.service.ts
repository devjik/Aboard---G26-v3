import api from './api';
import type { Route, CreateRoutePayload, UpdateRoutePayload } from '@/types/route.types';

const parseRoutes = (raw: any[]): Route[] =>
  (raw || []).map((r) => ({
    ...r,
    price: r.price ?? r.base_price,
    departure: r.departure ?? r.origin,
    totalSeats: r.totalSeats ?? r.total_seats,
    availableSeats: r.availableSeats ?? r.available_seats,
    departureTimes: r.departureTimes ?? r.departure_times ?? [],
  }));

export const routeService = {
  getRoutes: async (): Promise<Route[]> => {
    const { data } = await api.get('/routes');
    const routes = Array.isArray(data) ? data : data.routes ?? data.data ?? [];
    return parseRoutes(routes);
  },

  getRouteById: async (id: string): Promise<Route> => {
    const { data } = await api.get(`/routes/${id}`);
    const r = data.route ?? data.data ?? data;
    return parseRoutes([r])[0];
  },

  createRoute: async (payload: CreateRoutePayload): Promise<Route> => {
    const { data } = await api.post('/routes', payload);
    const r = data.route ?? data.data ?? data;
    return parseRoutes([r])[0];
  },

  updateRoute: async (id: string, payload: UpdateRoutePayload): Promise<Route> => {
    const { data } = await api.patch(`/routes/${id}`, payload);
    const r = data.route ?? data.data ?? { id, ...payload };
    return parseRoutes([r])[0];
  },

  updateRouteStatus: async (id: string, status: 'ACTIVE' | 'INACTIVE'): Promise<void> => {
    await api.patch(`/routes/${id}/status`, { status });
  },

  updateRouteSeats: async (id: string, totalSeats: number, availableSeats: number) => {
    const { data } = await api.patch(`/routes/${id}/seats`, { totalSeats, availableSeats });
    return { availabilityLabel: data.availabilityLabel };
  },

  deleteRoute: async (id: string): Promise<void> => {
    await api.delete(`/routes/${id}`);
  },

  getDashboardStats: async () => {
    const { data } = await api.get('/admin/stats');
    return data.stats ?? data;
  },
};
