import api from './api';
import type { InitiatePaymentPayload, PaymentResponse, Payment } from '@/types/payment.types';

export const paymentService = {
  initiatePayment: async (payload: InitiatePaymentPayload): Promise<PaymentResponse> => {
    const { data } = await api.post('/payments/init', payload);
    return {
      paymentUrl: data.paymentUrl || data.authorizationUrl,
      reference: data.reference,
    };
  },

  verifyPayment: async (reference: string): Promise<Payment> => {
    const { data } = await api.get(`/payments/verify/${encodeURIComponent(reference)}`);
    return data.payment ?? data.data;
  },
};
