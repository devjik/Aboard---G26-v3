import api from './api';
import type { LoginPayload, RegisterPayload, AuthResponse } from '@/types/auth.types';

const unwrap = (data: any): AuthResponse => ({
  user: data.user,
  tokens: data.tokens,
});

export const authService = {
  login: async (payload: LoginPayload): Promise<AuthResponse> => {
    const { data } = await api.post('/auth/login', {
      email: payload.email,
      password: payload.password,
    });
    return unwrap(data);
  },

  register: async (payload: RegisterPayload): Promise<AuthResponse> => {
    const { data } = await api.post('/auth/register', payload);
    return unwrap(data);
  },

  refreshToken: async (refreshToken: string): Promise<AuthResponse> => {
    const { data } = await api.post('/auth/refresh', { refreshToken });
    return unwrap(data);
  },

  getProfile: async (): Promise<AuthResponse['user']> => {
    const { data } = await api.get('/auth/me');
    return data.user;
  },

  logout: async (refreshToken?: string): Promise<void> => {
    await api.post('/auth/logout', { refreshToken }).catch(() => undefined);
  },
};
