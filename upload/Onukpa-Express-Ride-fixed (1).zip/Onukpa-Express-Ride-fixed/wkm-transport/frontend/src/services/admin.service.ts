import api from './api';
import type { DashboardStats, AdminFilters } from '@/types/admin.types';
import type { Booking } from '@/types/booking.types';
import type { Route } from '@/types/route.types';
import type { User } from '@/types/auth.types';
import type { PaginatedResponse } from '@/types/api.types';

export const adminService = {
  getDashboardStats: async (): Promise<DashboardStats> => {
    const { data } = await api.get('/admin/stats');
    return data.stats ?? data;
  },

  getAllBookings: async (filters?: AdminFilters) => {
    const { data } = await api.get('/admin/bookings', { params: filters });
    return data.bookings ?? data.data ?? [];
  },

  getAllRoutes: async (): Promise<PaginatedResponse<Route>> => {
    const { data } = await api.get('/routes', { params: { includePast: true } });
    const routes = Array.isArray(data) ? data : data.routes ?? [];
    return {
      success: true,
      data: routes,
      pagination: { total: routes.length, page: 1, limit: routes.length, totalPages: 1 },
    };
  },

  getAllUsers: async (): Promise<PaginatedResponse<User>> => ({
    success: true,
    data: [],
    pagination: { total: 0, page: 1, limit: 10, totalPages: 0 },
  }),
};
