import api from './api';
import type { Booking, CreateBookingPayload } from '@/types/booking.types';

export const bookingService = {
  createBooking: async (payload: CreateBookingPayload): Promise<Booking> => {
    const { data } = await api.post('/bookings', payload);
    return data.booking ?? data;
  },

  getBookings: async () => {
    const { data } = await api.get('/bookings');
    const list = data.bookings ?? data.data ?? data;
    return { data: Array.isArray(list) ? list : [] };
  },

  getBookingById: async (id: string): Promise<Booking> => {
    const { data } = await api.get(`/bookings/${id}`);
    return data.booking ?? data.data;
  },

  cancelBooking: async (id: string): Promise<Booking> => {
    const { data } = await api.post(`/bookings/${id}/cancel`);
    return data.booking ?? data.data;
  },

  track: async (ticketCode: string) => {
    const { data } = await api.get(`/bookings/track/${ticketCode}`);
    return data;
  },
};
