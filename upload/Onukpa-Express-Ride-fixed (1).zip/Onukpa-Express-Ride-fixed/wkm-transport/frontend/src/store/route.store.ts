import { create } from 'zustand';
import { routeService } from '@/services/route.service';
import type { Route } from '@/types/route.types';

interface RouteState {
  routes: Route[];
  isLoading: boolean;
  error: string | null;
  fetchRoutes: () => Promise<void>;
  getRoute: (id: string) => Route | undefined;
}

export const useRouteStore = create<RouteState>((set, get) => ({
  routes: [],
  isLoading: false,
  error: null,

  fetchRoutes: async () => {
    set({ isLoading: true, error: null });
    try {
      const routes = await routeService.getRoutes();
      set({ routes, isLoading: false });
    } catch (error: any) {
      set({
        error: error.response?.data?.message || 'Failed to fetch routes',
        isLoading: false,
      });
    }
  },

  getRoute: (id: string) => get().routes.find((route) => String(route.id) === String(id)),
}));
