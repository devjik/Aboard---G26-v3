import { Request, Response, NextFunction } from 'express';
import Joi from 'joi';
import { AppError } from '../utils/AppError';

export const validate = (schema: Record<string, Joi.ObjectSchema>) =>
  (req: Request, res: Response, next: NextFunction) => {
    const object = Object.keys(schema).reduce((acc: Record<string, unknown>, key) => {
      acc[key] = (req as any)[key];
      return acc;
    }, {});

    const { value, error } = Joi.object(schema)
      .prefs({ errors: { label: 'key' }, abortEarly: false })
      .validate(object);

    if (error) {
      const errorMessage = error.details.map((d) => d.message).join(', ');
      return next(new AppError(400, errorMessage));
    }

    Object.assign(req, value);
    return next();
  };
