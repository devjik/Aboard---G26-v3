import express, { Express, Request, Response } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import cookieParser from 'cookie-parser';
import passport from 'passport';
import swaggerUi from 'swagger-ui-express';

import { env } from './config/env';
import { jwtStrategy } from './config/passport';
import { successHandler, errorHandlerLogger } from './middleware/requestLogger';
import { errorHandler } from './middleware/errorHandler';
import { apiLimiter } from './middleware/rateLimiter';
import swaggerSpec from './config/swagger';
import prisma from './config/database';

import authRoutes from './modules/auth/auth.routes';
import routeRoutes from './modules/routes/route.routes';
import bookingRoutes from './modules/bookings/booking.routes';
import paymentRoutes from './modules/payments/payment.routes';
import adminRoutes from './modules/admin/admin.routes';
import webhookRoutes from './modules/webhooks/webhook.routes';

const app: Express = express();

if (env.env !== 'test') {
  app.use(successHandler);
  app.use(errorHandlerLogger);
}

app.use(helmet());
app.use(
  cors({
    origin: env.frontendUrl || 'http://localhost:3000',
    credentials: true,
  })
);
app.use(compression());
app.use(express.json({ limit: '32kb' }));
app.use(express.urlencoded({ extended: true, limit: '32kb' }));
app.use(cookieParser());

app.use(passport.initialize());
passport.use('jwt', jwtStrategy);

if (env.env === 'production') {
  app.use('/api', apiLimiter);
}

app.get('/health', (_req: Request, res: Response) => {
  res.json({ status: 'ok', service: 'onukpa-api' });
});

app.get('/ready', async (_req: Request, res: Response) => {
  try {
    await prisma.$queryRaw`SELECT 1`;
    res.json({ status: 'ready' });
  } catch {
    res.status(503).json({ status: 'not-ready' });
  }
});

app.use('/api/v1/docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));

const router = express.Router();
router.use('/auth', authRoutes);
router.use('/routes', routeRoutes);
router.use('/bookings', bookingRoutes);
router.use('/payments', paymentRoutes);
router.use('/admin', adminRoutes);
router.use('/webhooks', webhookRoutes);

app.use('/api/v1', router);

app.use(errorHandler);

export default app;
