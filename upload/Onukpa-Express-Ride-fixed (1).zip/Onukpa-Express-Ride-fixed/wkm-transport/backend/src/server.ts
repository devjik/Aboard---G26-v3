import dotenv from 'dotenv';
import http from 'http';
import app from './app';
import prisma from './config/database';
import logger from './config/logger';

dotenv.config();

const PORT = process.env.PORT || 5000;
const server = http.createServer(app);

server.listen(PORT, () => {
  logger.info(`Onukpa API running in ${process.env.NODE_ENV} mode on port ${PORT}`);
});

const shutdown = async (signal: string) => {
  logger.info(`${signal} received, shutting down`);
  server.close(async () => {
    await prisma.$disconnect().catch(() => undefined);
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 10_000).unref();
};

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

process.on('unhandledRejection', (err: any) => {
  logger.error(`Unhandled rejection: ${err?.message || err}`);
  shutdown('unhandledRejection');
});
