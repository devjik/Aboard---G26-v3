import express from 'express';
import { validate } from '../../middleware/validation';
import * as bookingValidation from './booking.validation';
import * as bookingController from './booking.controller';
import { auth, optionalAuth } from '../auth/auth.middleware';
import { catchAsync } from '../../utils/AppError';
import { apiLimiter } from '../../middleware/rateLimiter';

const router = express.Router();

router.get(
  '/track/:ticketCode',
  validate(bookingValidation.trackBooking),
  catchAsync(bookingController.trackBooking)
);

router.post(
  '/',
  apiLimiter,
  optionalAuth,
  validate(bookingValidation.createBooking),
  catchAsync(bookingController.createBooking)
);

router.get('/', auth(), catchAsync(bookingController.getUserBookings));
router.get(
  '/:bookingId',
  auth(),
  validate(bookingValidation.getBooking),
  catchAsync(bookingController.getBooking)
);
router.post(
  '/:bookingId/cancel',
  auth(),
  validate(bookingValidation.cancelBooking),
  catchAsync(bookingController.cancelBooking)
);

export default router;
