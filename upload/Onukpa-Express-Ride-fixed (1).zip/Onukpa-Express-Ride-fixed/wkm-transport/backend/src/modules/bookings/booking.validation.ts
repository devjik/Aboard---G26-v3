import Joi from 'joi';

const ghanaPhone = Joi.string()
  .required()
  .custom((value, helpers) => {
    const digits = String(value).replace(/[\s-]/g, '');
    const normalised = digits.startsWith('+') ? digits.slice(1) : digits;
    const ok =
      /^(0[235]\d{8})$/.test(normalised) ||
      /^(233[235]\d{8})$/.test(normalised);
    if (!ok) return helpers.error('any.invalid');
    return value;
  }, 'Ghana phone')
  .messages({ 'any.invalid': 'Enter a valid Ghana mobile number' });

export const createBooking = {
  body: Joi.object().keys({
    routeId: Joi.string().uuid().required(),
    numberOfTickets: Joi.number().integer().min(1).max(10).required(),
    passengerName: Joi.string().min(2).max(120).required(),
    passengerPhone: ghanaPhone,
  }),
};

export const getBooking = {
  params: Joi.object().keys({
    bookingId: Joi.string().required(),
  }),
};

export const cancelBooking = {
  params: Joi.object().keys({
    bookingId: Joi.string().required(),
  }),
};

export const trackBooking = {
  params: Joi.object().keys({
    ticketCode: Joi.string().required(),
  }),
};
