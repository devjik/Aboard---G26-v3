import { Request, Response } from 'express';
import httpStatus from 'http-status-codes';
import prisma from '../../config/database';
import { generateTicketNumber } from '../../utils/generateTicket';
import { AppError } from '../../utils/AppError';

export const createBooking = async (req: Request, res: Response) => {
  const { routeId, numberOfTickets, passengerName, passengerPhone } = req.body;
  const userId = (req.user as any)?.id ?? null;

  const booking = await prisma.$transaction(async (tx) => {
    const updated = await tx.route.updateMany({
      where: {
        id: routeId,
        status: 'ACTIVE',
        availableSeats: { gte: numberOfTickets },
        departureTime: { gt: new Date() },
      },
      data: { availableSeats: { decrement: numberOfTickets } },
    });

    if (updated.count !== 1) {
      throw new AppError(
        httpStatus.CONFLICT,
        'Route not found, inactive, already departed, or not enough seats'
      );
    }

    const route = await tx.route.findUnique({ where: { id: routeId } });
    if (!route) throw new AppError(httpStatus.NOT_FOUND, 'Route not found');

    return tx.booking.create({
      data: {
        userId,
        routeId,
        passengerName,
        passengerPhone,
        numberOfTickets,
        totalAmount: Number(route.price) * numberOfTickets,
        ticketNumber: generateTicketNumber(),
        status: 'PENDING',
      },
      include: { route: true },
    });
  });

  res.status(httpStatus.CREATED).json({ success: true, booking });
};

export const getUserBookings = async (req: Request, res: Response) => {
  const user = req.user as any;
  const bookings = await prisma.booking.findMany({
    where: { userId: user.id },
    include: { route: true, payment: true },
    orderBy: { createdAt: 'desc' },
  });
  res.json({ success: true, bookings });
};

export const getBooking = async (req: Request, res: Response) => {
  const user = req.user as any;
  const booking = await prisma.booking.findFirst({
    where: {
      id: req.params.bookingId,
      ...(user.role === 'ADMIN' ? {} : { userId: user.id }),
    },
    include: { route: true, payment: true },
  });

  if (!booking) {
    throw new AppError(httpStatus.NOT_FOUND, 'Booking not found');
  }
  res.json({ success: true, booking });
};

export const cancelBooking = async (req: Request, res: Response) => {
  const user = req.user as any;

  const result = await prisma.$transaction(async (tx) => {
    const booking = await tx.booking.findFirst({
      where: {
        id: req.params.bookingId,
        ...(user.role === 'ADMIN' ? {} : { userId: user.id }),
      },
      include: { payment: true },
    });

    if (!booking) {
      throw new AppError(httpStatus.BAD_REQUEST, 'Valid booking not found');
    }
    if (booking.status === 'CANCELLED') {
      throw new AppError(httpStatus.BAD_REQUEST, 'Booking already cancelled');
    }
    if (booking.status === 'COMPLETED') {
      throw new AppError(httpStatus.CONFLICT, 'Completed trips cannot be cancelled');
    }
    if (booking.status === 'CONFIRMED' || booking.payment?.status === 'SUCCESS') {
      throw new AppError(
        httpStatus.CONFLICT,
        'Paid bookings cannot be cancelled here. Contact support for a refund.'
      );
    }

    const cancelled = await tx.booking.update({
      where: { id: booking.id },
      data: { status: 'CANCELLED' },
    });

    await tx.route.update({
      where: { id: booking.routeId },
      data: { availableSeats: { increment: booking.numberOfTickets } },
    });

    return cancelled;
  });

  res.json({ success: true, booking: result });
};

export const trackBooking = async (req: Request, res: Response) => {
  const { ticketCode } = req.params;
  const booking = await prisma.booking.findFirst({
    where: { ticketNumber: ticketCode.toUpperCase() },
    include: { route: true },
  });

  if (!booking) {
    throw new AppError(httpStatus.NOT_FOUND, 'Ticket not found');
  }

  const now = new Date();
  const departure = new Date(booking.route.departureTime);
  const arrival = new Date(booking.route.arrivalTime);

  let status = 'Scheduled';
  let eta: string | null = departure.toISOString();
  if (booking.status === 'CANCELLED') {
    status = 'Cancelled';
    eta = null;
  } else if (now >= arrival) {
    status = 'Arrived';
    eta = null;
  } else if (now >= departure) {
    status = 'In Transit';
    eta = arrival.toISOString();
  }

  res.json({
    success: true,
    status,
    eta,
    booking: {
      ticket_code: booking.ticketNumber,
      destination: booking.route.destination,
      departure: booking.route.departure,
      departure_time: booking.route.departureTime,
      travel_date: booking.route.departureTime,
      payment_status: booking.status,
    },
  });
};
