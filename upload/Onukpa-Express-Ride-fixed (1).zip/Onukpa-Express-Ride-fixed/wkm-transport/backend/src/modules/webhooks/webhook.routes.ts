import express from 'express';
import { handleHubtelWebhook } from './webhook.controller';
import { catchAsync } from '../../utils/AppError';

const router = express.Router();

router.post('/hubtel', catchAsync(handleHubtelWebhook));
router.post('/', catchAsync(handleHubtelWebhook));

export default router;
