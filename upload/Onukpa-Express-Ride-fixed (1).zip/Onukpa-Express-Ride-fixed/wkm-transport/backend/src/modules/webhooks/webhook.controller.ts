import { Request, Response } from 'express';
import httpStatus from 'http-status-codes';
import { env } from '../../config/env';
import { AppError } from '../../utils/AppError';
import { HubtelProvider } from '../payments/providers/hubtel.provider';
import { applyPaymentResult } from './webhook.service';
import logger from '../../config/logger';

const hubtel = new HubtelProvider();

const extractReference = (body: any): string | null =>
  body?.ClientReference ||
  body?.clientReference ||
  body?.Data?.ClientReference ||
  body?.data?.clientReference ||
  body?.reference ||
  null;

export const handleHubtelWebhook = async (req: Request, res: Response) => {
  if (env.hubtel.webhookSecret) {
    const provided =
      req.get('x-webhook-secret') ||
      req.get('x-hubtel-secret') ||
      (req.query.secret as string | undefined);
    if (provided !== env.hubtel.webhookSecret) {
      throw new AppError(httpStatus.UNAUTHORIZED, 'Invalid webhook secret');
    }
  } else if (env.env === 'production' && !env.hubtel.mock) {
    throw new AppError(httpStatus.UNAUTHORIZED, 'Webhook secret is not configured');
  }

  const body = req.body || {};
  const reference = extractReference(body);
  if (!reference) {
    throw new AppError(httpStatus.BAD_REQUEST, 'Missing client reference');
  }

  const verification = await hubtel.verifyPayment(reference);
  await applyPaymentResult(
    reference,
    verification.status,
    verification.amount || undefined
  );

  logger.info(`Hubtel webhook processed for reference ${reference} status=${verification.status}`);
  res.status(httpStatus.OK).json({ success: true });
};

export const handleWebhook = handleHubtelWebhook;
