import path from 'path';
import fs from 'fs';
import prisma from '../../config/database';
import { generateTicketPDF } from '../../utils/generatePDF';
import logger from '../../config/logger';

export const applyPaymentResult = async (
  reference: string,
  status: 'SUCCESS' | 'FAILED' | 'PENDING',
  expectedAmount?: number
) => {
  const payment = await prisma.payment.findUnique({
    where: { reference },
    include: { booking: { include: { user: true, route: true } } },
  });
  if (!payment) return null;
  if (payment.status !== 'PENDING') return payment;

  if (status === 'SUCCESS') {
    if (expectedAmount && Number(payment.amount) !== Number(expectedAmount) && expectedAmount !== 0) {
      logger.error(`Amount mismatch for ${reference}: expected ${payment.amount}, got ${expectedAmount}`);
      return payment;
    }

    const updated = await prisma.$transaction(async (tx) => {
      const pay = await tx.payment.updateMany({
        where: { id: payment.id, status: 'PENDING' },
        data: { status: 'SUCCESS' },
      });
      if (pay.count !== 1) return null;
      await tx.booking.update({
        where: { id: payment.bookingId },
        data: { status: 'CONFIRMED' },
      });
      return tx.payment.findUnique({
        where: { id: payment.id },
        include: { booking: { include: { user: true, route: true } } },
      });
    });

    if (updated?.booking) {
      try {
        const tmpDir = path.join(__dirname, '../../../tmp');
        fs.mkdirSync(tmpDir, { recursive: true });
        const outputPath = path.join(tmpDir, `ticket-${updated.booking.ticketNumber}.pdf`);
        await generateTicketPDF(updated.booking, outputPath);
      } catch (e) {
        logger.error('Failed to generate ticket PDF');
      }
    }
    return updated;
  }

  if (status === 'FAILED') {
    return prisma.$transaction(async (tx) => {
      const pay = await tx.payment.updateMany({
        where: { id: payment.id, status: 'PENDING' },
        data: { status: 'FAILED' },
      });
      if (pay.count !== 1) return payment;
      await tx.booking.update({
        where: { id: payment.bookingId },
        data: { status: 'CANCELLED' },
      });
      await tx.route.update({
        where: { id: payment.booking.routeId },
        data: { availableSeats: { increment: payment.booking.numberOfTickets } },
      });
      return tx.payment.findUnique({ where: { id: payment.id } });
    });
  }

  return payment;
};
