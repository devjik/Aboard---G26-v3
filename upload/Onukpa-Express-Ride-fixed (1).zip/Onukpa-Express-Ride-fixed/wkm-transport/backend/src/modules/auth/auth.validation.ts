import Joi from 'joi';

const password = Joi.string()
  .required()
  .min(8)
  .max(72)
  .pattern(/[A-Za-z]/)
  .pattern(/[0-9]/)
  .messages({
    'string.min': 'Password must be at least 8 characters',
    'string.pattern.base': 'Password must contain at least one letter and one number',
  });

export const register = {
  body: Joi.object().keys({
    email: Joi.string().required().email(),
    password,
    firstName: Joi.string().required().min(2).max(80),
    lastName: Joi.string().required().min(2).max(80),
    phone: Joi.string().optional().allow('', null),
  }),
};

export const login = {
  body: Joi.object().keys({
    email: Joi.string().required().email(),
    password: Joi.string().required(),
  }),
};

export const changePassword = {
  body: Joi.object().keys({
    currentPassword: Joi.string().required(),
    newPassword: password,
  }),
};

export const refresh = {
  body: Joi.object().keys({
    refreshToken: Joi.string().required(),
  }),
};
