import express from 'express';
import { validate } from '../../middleware/validation';
import * as authValidation from './auth.validation';
import * as authController from './auth.controller';
import { authLimiter } from '../../middleware/rateLimiter';
import { auth } from './auth.middleware';
import { catchAsync } from '../../utils/AppError';

const router = express.Router();

router.post('/register', authLimiter, validate(authValidation.register), catchAsync(authController.register));
router.post('/login', authLimiter, validate(authValidation.login), catchAsync(authController.login));
router.post('/refresh', validate(authValidation.refresh), catchAsync(authController.refresh));
router.post('/logout', catchAsync(authController.logout));
router.get('/me', auth(), catchAsync(authController.getMe));
router.get('/verify', auth(), catchAsync(authController.getMe));
router.put(
  '/change-password',
  auth(),
  validate(authValidation.changePassword),
  catchAsync(authController.changePassword)
);

export default router;
