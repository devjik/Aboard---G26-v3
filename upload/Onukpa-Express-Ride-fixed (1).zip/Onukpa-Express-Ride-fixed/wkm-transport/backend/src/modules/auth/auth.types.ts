export type UserTokenPayload = {
  sub: string;
  type: 'access' | 'refresh';
  role: 'USER' | 'ADMIN';
};

export type AuthTokens = {
  access: {
    token: string;
    expires: Date;
  };
  refresh: {
    token: string;
    expires: Date;
  };
};

export type SafeUser = {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  phone: string | null;
  role: 'USER' | 'ADMIN';
};
