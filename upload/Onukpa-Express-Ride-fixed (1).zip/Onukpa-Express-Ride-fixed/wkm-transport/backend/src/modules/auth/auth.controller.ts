import { Request, Response } from 'express';
import httpStatus from 'http-status-codes';
import bcrypt from 'bcryptjs';
import prisma from '../../config/database';
import { AppError } from '../../utils/AppError';
import { generateAuthTokens, rotateRefreshToken, revokeRefreshToken, revokeAllUserTokens } from './auth.service';

const BCRYPT_ROUNDS = 12;

const toSafeUser = (user: {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  phone?: string | null;
  role: string;
}) => ({
  id: user.id,
  email: user.email,
  firstName: user.firstName,
  lastName: user.lastName,
  phone: user.phone ?? null,
  role: user.role,
});

export const register = async (req: Request, res: Response) => {
  const { email, password, firstName, lastName, phone } = req.body;

  if (await prisma.user.findUnique({ where: { email: email.toLowerCase() } })) {
    throw new AppError(httpStatus.BAD_REQUEST, 'Email already taken');
  }

  const hashedPassword = await bcrypt.hash(password, BCRYPT_ROUNDS);

  const user = await prisma.user.create({
    data: {
      email: email.toLowerCase(),
      password: hashedPassword,
      firstName,
      lastName,
      phone: phone || null,
    },
  });

  const tokens = await generateAuthTokens(user);
  res.status(httpStatus.CREATED).json({ success: true, user: toSafeUser(user), tokens });
};

export const login = async (req: Request, res: Response) => {
  const { email, password } = req.body;

  const user = await prisma.user.findUnique({ where: { email: email.toLowerCase() } });
  if (!user || !(await bcrypt.compare(password, user.password))) {
    throw new AppError(httpStatus.UNAUTHORIZED, 'Incorrect email or password');
  }

  const tokens = await generateAuthTokens(user);
  res.json({ success: true, user: toSafeUser(user), tokens });
};

export const getMe = async (req: Request, res: Response) => {
  res.json({ success: true, user: req.user });
};

export const changePassword = async (req: Request, res: Response) => {
  const { currentPassword, newPassword } = req.body;
  const userId = (req.user as any).id;
  const user = await prisma.user.findUnique({ where: { id: userId } });

  if (!user || !(await bcrypt.compare(currentPassword, user.password))) {
    throw new AppError(httpStatus.UNAUTHORIZED, 'Incorrect current password');
  }

  const hashedPassword = await bcrypt.hash(newPassword, BCRYPT_ROUNDS);
  await prisma.user.update({
    where: { id: user.id },
    data: { password: hashedPassword },
  });
  await revokeAllUserTokens(user.id);

  res.json({ success: true, message: 'Password updated successfully. Please log in again.' });
};

export const refresh = async (req: Request, res: Response) => {
  const result = await rotateRefreshToken(req.body.refreshToken);
  res.json({ success: true, user: toSafeUser(result.user as any), tokens: result.tokens });
};

export const logout = async (req: Request, res: Response) => {
  if (req.body.refreshToken) {
    await revokeRefreshToken(req.body.refreshToken);
  }
  res.json({ success: true, message: 'Logged out' });
};
