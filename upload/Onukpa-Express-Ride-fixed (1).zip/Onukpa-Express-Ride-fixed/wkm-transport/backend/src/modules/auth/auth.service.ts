import crypto from 'crypto';
import jwt from 'jsonwebtoken';
import { env } from '../../config/env';
import prisma from '../../config/database';
import { AppError } from '../../utils/AppError';
import { UserTokenPayload, AuthTokens } from './auth.types';

const hashToken = (token: string) =>
  crypto.createHash('sha256').update(token).digest('hex');

export const generateToken = (
  userId: string,
  role: string,
  expires: Date,
  type: 'access' | 'refresh' = 'access',
  secret: string = env.jwtSecret
): string => {
  const payload: UserTokenPayload = {
    sub: userId,
    type,
    role: role as 'USER' | 'ADMIN',
  };
  const seconds = Math.max(1, Math.floor((expires.getTime() - Date.now()) / 1000));
  return jwt.sign(payload, secret, { expiresIn: seconds });
};

export const generateAuthTokens = async (user: {
  id: string;
  role: string;
}): Promise<AuthTokens> => {
  const accessTokenExpires = new Date(Date.now() + 60 * 60 * 1000);
  const refreshTokenExpires = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

  const accessToken = generateToken(user.id, user.role, accessTokenExpires, 'access');
  const refreshToken = generateToken(user.id, user.role, refreshTokenExpires, 'refresh');

  await prisma.refreshToken.create({
    data: {
      tokenHash: hashToken(refreshToken),
      userId: user.id,
      expiresAt: refreshTokenExpires,
    },
  });

  return {
    access: { token: accessToken, expires: accessTokenExpires },
    refresh: { token: refreshToken, expires: refreshTokenExpires },
  };
};

export const rotateRefreshToken = async (refreshToken: string): Promise<{
  user: { id: string; email: string; firstName: string; lastName: string; phone: string | null; role: string };
  tokens: AuthTokens;
}> => {
  let payload: UserTokenPayload;
  try {
    payload = jwt.verify(refreshToken, env.jwtSecret) as UserTokenPayload;
  } catch {
    throw new AppError(401, 'Invalid refresh token');
  }
  if (payload.type !== 'refresh') {
    throw new AppError(401, 'Invalid token type');
  }

  const tokenHash = hashToken(refreshToken);
  const stored = await prisma.refreshToken.findFirst({
    where: { tokenHash, revokedAt: null, expiresAt: { gt: new Date() } },
  });
  if (!stored || stored.userId !== payload.sub) {
    throw new AppError(401, 'Refresh token expired or revoked');
  }

  await prisma.refreshToken.update({
    where: { id: stored.id },
    data: { revokedAt: new Date() },
  });

  const user = await prisma.user.findUnique({
    where: { id: payload.sub },
    select: { id: true, email: true, firstName: true, lastName: true, phone: true, role: true },
  });
  if (!user) throw new AppError(401, 'User no longer exists');

  const tokens = await generateAuthTokens(user);
  return { user, tokens };
};

export const revokeRefreshToken = async (refreshToken: string) => {
  const tokenHash = hashToken(refreshToken);
  await prisma.refreshToken.updateMany({
    where: { tokenHash, revokedAt: null },
    data: { revokedAt: new Date() },
  });
};

export const revokeAllUserTokens = async (userId: string) => {
  await prisma.refreshToken.updateMany({
    where: { userId, revokedAt: null },
    data: { revokedAt: new Date() },
  });
};
