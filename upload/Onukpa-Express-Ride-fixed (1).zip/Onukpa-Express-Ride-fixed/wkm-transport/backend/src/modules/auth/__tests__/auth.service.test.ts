import { generateToken } from '../auth.service';

jest.mock('../../../config/env', () => ({
  env: { jwtSecret: 'test-secret-test-secret-32chars!', frontendUrl: 'http://localhost:3000' },
}));

jest.mock('../../../config/database', () => ({
  __esModule: true,
  default: {
    refreshToken: { create: jest.fn(), findFirst: jest.fn(), update: jest.fn(), updateMany: jest.fn() },
    user: { findUnique: jest.fn() },
  },
}));

describe('generateToken', () => {
  it('returns a JWT string', () => {
    const expires = new Date(Date.now() + 60_000);
    const token = generateToken('user-1', 'USER', expires, 'access', 'test-secret-test-secret-32chars!');
    expect(token.split('.')).toHaveLength(3);
  });
});
