import passport from 'passport';
import { Request, Response, NextFunction } from 'express';
import httpStatus from 'http-status-codes';
import { AppError } from '../../utils/AppError';

const verifyCallback =
  (req: Request, resolve: () => void, reject: (err: Error) => void, requiredRights: string[]) =>
  async (err: any, user: any, info: any) => {
    if (err || info || !user) {
      return reject(new AppError(httpStatus.UNAUTHORIZED, 'Please authenticate'));
    }
    (req as any).user = user;

    if (requiredRights.length) {
      const userRights =
        user.role === 'ADMIN'
          ? ['manageUsers', 'manageRoutes', 'manageBookings', 'manageSystem']
          : [];
      const hasRequiredRights = requiredRights.every((right) => userRights.includes(right));
      if (!hasRequiredRights) {
        return reject(new AppError(httpStatus.FORBIDDEN, 'Forbidden'));
      }
    }

    resolve();
  };

export const auth =
  (...requiredRights: string[]) =>
  async (req: Request, res: Response, next: NextFunction) => {
    return new Promise<void>((resolve, reject) => {
      passport.authenticate(
        'jwt',
        { session: false },
        verifyCallback(req, resolve, reject, requiredRights)
      )(req, res, next);
    })
      .then(() => next())
      .catch((err) => {
        const status = err.statusCode || httpStatus.UNAUTHORIZED;
        res.status(status).json({ success: false, message: err.message });
      });
  };

export const optionalAuth = async (req: Request, res: Response, next: NextFunction) => {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return next();
  }
  return auth()(req, res, next);
};
