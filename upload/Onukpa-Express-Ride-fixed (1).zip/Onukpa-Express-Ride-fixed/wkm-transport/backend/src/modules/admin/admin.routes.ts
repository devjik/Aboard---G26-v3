import express from 'express';
import { getDashboardStats, getAllBookings } from './admin.controller';
import { auth } from '../auth/auth.middleware';
import { catchAsync } from '../../utils/AppError';

const router = express.Router();

router.use(auth('manageRoutes'));

router.get('/stats', catchAsync(getDashboardStats));
router.get('/bookings', catchAsync(getAllBookings));

export default router;
