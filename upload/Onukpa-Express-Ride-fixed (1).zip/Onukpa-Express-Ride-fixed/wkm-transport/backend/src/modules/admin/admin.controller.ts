import { Request, Response } from 'express';
import prisma from '../../config/database';

export const getDashboardStats = async (_req: Request, res: Response) => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const weekAgo = new Date(today);
  weekAgo.setDate(weekAgo.getDate() - 6);

  const [
    totalUsers,
    totalBookings,
    totalRoutes,
    activeRoutes,
    revenueRaw,
    todayBookings,
    todayRevenueRaw,
    confirmedBookings,
    pendingBookings,
  ] = await Promise.all([
    prisma.user.count({ where: { role: 'USER' } }),
    prisma.booking.count(),
    prisma.route.count(),
    prisma.route.count({ where: { status: 'ACTIVE' } }),
    prisma.payment.aggregate({ where: { status: 'SUCCESS' }, _sum: { amount: true } }),
    prisma.booking.count({ where: { createdAt: { gte: today } } }),
    prisma.payment.aggregate({
      where: { status: 'SUCCESS', createdAt: { gte: today } },
      _sum: { amount: true },
    }),
    prisma.booking.count({
      where: { createdAt: { gte: today }, status: 'CONFIRMED' },
    }),
    prisma.booking.count({ where: { status: 'PENDING' } }),
  ]);

  const recentBookings = await prisma.booking.findMany({
    take: 20,
    orderBy: { createdAt: 'desc' },
    include: {
      user: { select: { firstName: true, lastName: true } },
      route: { select: { departure: true, destination: true } },
    },
  });

  const routesFill = await prisma.route.findMany({
    where: { departureTime: { gte: today } },
    orderBy: { departureTime: 'asc' },
    take: 50,
  });

  const rawChart = await prisma.booking.groupBy({
    by: ['createdAt'],
    where: { createdAt: { gte: weekAgo } },
    _count: { id: true },
  });

  const byDay: Record<string, number> = {};
  for (let i = 0; i < 7; i++) {
    const d = new Date(weekAgo);
    d.setDate(weekAgo.getDate() + i);
    byDay[d.toISOString().slice(0, 10)] = 0;
  }
  for (const row of rawChart) {
    const key = new Date(row.createdAt).toISOString().slice(0, 10);
    if (key in byDay) byDay[key] += row._count.id;
  }
  const chartData = Object.entries(byDay).map(([date, count]) => ({ date, count, revenue: 0 }));

  const mappedRecent = recentBookings.map((b) => ({
    id: b.id,
    ticketNumber: b.ticketNumber,
    status: b.status,
    totalAmount: b.totalAmount,
    total_amount: b.totalAmount,
    createdAt: b.createdAt,
    created_at: b.createdAt,
    passengerName: b.passengerName,
    passenger_name: b.passengerName,
    departure: b.route.departure,
    origin: b.route.departure,
    destination: b.route.destination,
  }));

  const mappedFill = routesFill.map((r) => ({
    id: r.id,
    origin: r.departure,
    departure: r.departure,
    destination: r.destination,
    total_seats: r.totalSeats,
    available_seats: r.availableSeats,
    status: r.status,
    base_price: r.price,
  }));

  const stats = {
    totalUsers,
    totalBookings,
    totalRoutes,
    activeRoutes,
    totalRevenue: revenueRaw._sum.amount || 0,
    todayBookings,
    todayRevenue: todayRevenueRaw._sum.amount || 0,
    confirmedBookings,
    pendingBookings,
    popularRoutes: [],
    chartData,
    recentBookings: mappedRecent,
    routesFill: mappedFill,
  };

  res.json({ success: true, stats, recentBookings: mappedRecent });
};

export const getAllBookings = async (req: Request, res: Response) => {
  const status = req.query.status as string | undefined;
  const bookings = await prisma.booking.findMany({
    where: status && status !== 'ALL' ? { status: status as any } : {},
    include: { route: true, payment: true },
    orderBy: { createdAt: 'desc' },
    take: 200,
  });
  res.json({
    success: true,
    bookings: bookings.map((b) => ({
      ...b,
      passenger_name: b.passengerName,
      total_amount: b.totalAmount,
      origin: b.route.departure,
      departure: b.route.departure,
      destination: b.route.destination,
    })),
  });
};
