import express from 'express';
import { validate } from '../../middleware/validation';
import * as routeValidation from './route.validation';
import * as routeController from './route.controller';
import { auth } from '../auth/auth.middleware';
import { catchAsync } from '../../utils/AppError';

const router = express.Router();

router.get('/', catchAsync(routeController.getRoutes));
router.get('/:routeId', catchAsync(routeController.getRoute));

router.post(
  '/',
  auth('manageRoutes'),
  validate(routeValidation.createRoute),
  catchAsync(routeController.createRoute)
);
router.patch(
  '/:routeId',
  auth('manageRoutes'),
  validate(routeValidation.updateRoute),
  catchAsync(routeController.updateRoute)
);
router.put(
  '/:routeId',
  auth('manageRoutes'),
  validate(routeValidation.updateRoute),
  catchAsync(routeController.updateRoute)
);
router.patch(
  '/:routeId/status',
  auth('manageRoutes'),
  catchAsync(routeController.updateRouteStatus)
);
router.patch(
  '/:routeId/seats',
  auth('manageRoutes'),
  catchAsync(routeController.updateRouteSeats)
);
router.delete(
  '/:routeId',
  auth('manageRoutes'),
  validate(routeValidation.deleteRoute),
  catchAsync(routeController.deleteRoute)
);

export default router;
