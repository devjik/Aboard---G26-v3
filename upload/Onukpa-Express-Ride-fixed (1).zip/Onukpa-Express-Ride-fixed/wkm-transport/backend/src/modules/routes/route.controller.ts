import { Request, Response } from 'express';
import httpStatus from 'http-status-codes';
import prisma from '../../config/database';
import { AppError } from '../../utils/AppError';

export const createRoute = async (req: Request, res: Response) => {
  const {
    departure,
    destination,
    price,
    departureTime,
    arrivalTime,
    totalSeats,
    availableSeats,
  } = req.body;

  const seats = Number(totalSeats);
  const available = availableSeats == null ? seats : Number(availableSeats);
  if (available > seats) {
    throw new AppError(httpStatus.BAD_REQUEST, 'availableSeats cannot exceed totalSeats');
  }

  const route = await prisma.route.create({
    data: {
      departure,
      destination,
      price,
      departureTime,
      arrivalTime,
      totalSeats: seats,
      availableSeats: available,
    },
  });
  res.status(httpStatus.CREATED).json({ success: true, route });
};

export const getRoutes = async (req: Request, res: Response) => {
  const includePast = req.query.includePast === 'true';
  const routes = await prisma.route.findMany({
    where: {
      status: 'ACTIVE',
      ...(includePast ? {} : { departureTime: { gt: new Date() } }),
    },
    orderBy: { departureTime: 'asc' },
  });
  res.json(routes);
};

export const getRoute = async (req: Request, res: Response) => {
  const route = await prisma.route.findUnique({
    where: { id: req.params.routeId },
  });
  if (!route) {
    throw new AppError(httpStatus.NOT_FOUND, 'Route not found');
  }
  res.json({ success: true, route });
};

export const updateRoute = async (req: Request, res: Response) => {
  const data = { ...req.body };
  if (data.availableSeats != null && data.totalSeats != null && data.availableSeats > data.totalSeats) {
    throw new AppError(httpStatus.BAD_REQUEST, 'availableSeats cannot exceed totalSeats');
  }
  const route = await prisma.route.update({
    where: { id: req.params.routeId },
    data,
  });
  res.json({ success: true, route });
};

export const updateRouteStatus = async (req: Request, res: Response) => {
  const { status } = req.body;
  if (!['ACTIVE', 'INACTIVE'].includes(status)) {
    throw new AppError(httpStatus.BAD_REQUEST, 'Status must be ACTIVE or INACTIVE');
  }
  const route = await prisma.route.update({
    where: { id: req.params.routeId },
    data: { status },
  });
  res.json({ success: true, route, status: route.status });
};

export const updateRouteSeats = async (req: Request, res: Response) => {
  const totalSeats = req.body.totalSeats ?? req.body.total_seats;
  const availableSeats = req.body.availableSeats ?? req.body.available_seats;
  const existing = await prisma.route.findUnique({ where: { id: req.params.routeId } });
  if (!existing) throw new AppError(httpStatus.NOT_FOUND, 'Route not found');

  const newTotal = totalSeats ?? existing.totalSeats;
  const newAvailable = availableSeats ?? existing.availableSeats;
  if (newAvailable > newTotal || newAvailable < 0) {
    throw new AppError(httpStatus.BAD_REQUEST, 'Available seats must be between 0 and total seats');
  }

  const route = await prisma.route.update({
    where: { id: req.params.routeId },
    data: { totalSeats: newTotal, availableSeats: newAvailable },
  });
  res.json({ success: true, route });
};

export const deleteRoute = async (req: Request, res: Response) => {
  const bookings = await prisma.booking.count({
    where: { routeId: req.params.routeId, status: { not: 'CANCELLED' } },
  });
  if (bookings > 0) {
    throw new AppError(httpStatus.CONFLICT, 'Cannot delete a route that has bookings. Mark it inactive instead.');
  }
  await prisma.route.delete({
    where: { id: req.params.routeId },
  });
  res.status(httpStatus.NO_CONTENT).send();
};
