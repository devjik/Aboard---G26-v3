import express from 'express';
import { initPayment, verifyPayment } from './payment.controller';
import { optionalAuth } from '../auth/auth.middleware';
import { validate } from '../../middleware/validation';
import * as paymentValidation from './payment.validation';
import { catchAsync } from '../../utils/AppError';

const router = express.Router();

router.post(
  '/init',
  optionalAuth,
  validate(paymentValidation.initPayment),
  catchAsync(initPayment)
);
router.post(
  '/initiate',
  optionalAuth,
  validate(paymentValidation.initPayment),
  catchAsync(initPayment)
);
router.get(
  '/verify/:reference',
  validate(paymentValidation.verifyPayment),
  catchAsync(verifyPayment)
);

export default router;
