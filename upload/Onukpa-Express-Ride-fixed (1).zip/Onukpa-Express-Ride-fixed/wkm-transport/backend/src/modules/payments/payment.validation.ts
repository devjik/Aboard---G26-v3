import Joi from 'joi';

export const initPayment = {
  body: Joi.object().keys({
    bookingId: Joi.string().uuid().required(),
    provider: Joi.string().valid('hubtel').default('hubtel'),
  }),
};

export const verifyPayment = {
  params: Joi.object().keys({
    reference: Joi.string().required(),
  }),
};
