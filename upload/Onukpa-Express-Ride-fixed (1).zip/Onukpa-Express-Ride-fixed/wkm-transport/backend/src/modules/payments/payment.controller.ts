import { Request, Response } from 'express';
import httpStatus from 'http-status-codes';
import crypto from 'crypto';
import prisma from '../../config/database';
import { HubtelProvider } from './providers/hubtel.provider';
import { AppError } from '../../utils/AppError';
import { applyPaymentResult } from '../webhooks/webhook.service';

const providers = {
  hubtel: new HubtelProvider(),
};

export const initPayment = async (req: Request, res: Response) => {
  const { bookingId, provider = 'hubtel' } = req.body;
  const user = req.user as any;

  const booking = await prisma.booking.findUnique({
    where: { id: bookingId },
    include: { user: true, payment: true, route: true },
  });

  if (!booking || booking.status !== 'PENDING') {
    throw new AppError(httpStatus.BAD_REQUEST, 'Invalid or already processed booking');
  }

  if (user && booking.userId && booking.userId !== user.id && user.role !== 'ADMIN') {
    throw new AppError(httpStatus.FORBIDDEN, 'This booking does not belong to you');
  }

  if (booking.payment && booking.payment.status === 'SUCCESS') {
    throw new AppError(httpStatus.BAD_REQUEST, 'Booking already paid');
  }

  const selectedProvider = providers[provider as keyof typeof providers];
  if (!selectedProvider) {
    throw new AppError(httpStatus.BAD_REQUEST, 'Invalid payment provider');
  }

  const reference =
    booking.payment?.reference ||
    `PAY-${crypto.randomBytes(8).toString('hex').toUpperCase()}`;

  const amount = Number(booking.totalAmount);

  const initResult = await selectedProvider.initializePayment(amount, 'GHS', reference, {
    name: booking.passengerName,
    phone: booking.passengerPhone,
    email: booking.user?.email,
  });

  if (!initResult.success) {
    throw new AppError(httpStatus.BAD_GATEWAY, initResult.error || 'Payment gateway error');
  }

  const payment = booking.payment
    ? await prisma.payment.update({
        where: { id: booking.payment.id },
        data: { reference, amount, provider, status: 'PENDING' },
      })
    : await prisma.payment.create({
        data: {
          bookingId,
          amount,
          provider,
          reference,
          status: 'PENDING',
        },
      });

  res.json({
    success: true,
    payment,
    authorizationUrl: initResult.authorizationUrl,
    paymentUrl: initResult.authorizationUrl,
    reference: initResult.reference,
  });
};

export const verifyPayment = async (req: Request, res: Response) => {
  const { reference } = req.params;
  const payment = await prisma.payment.findUnique({
    where: { reference },
    include: { booking: { include: { route: true } } },
  });
  if (!payment) throw new AppError(httpStatus.NOT_FOUND, 'Payment not found');

  const provider = providers[payment.provider as keyof typeof providers] || providers.hubtel;
  const verification = await provider.verifyPayment(reference);

  if (verification.status !== 'PENDING') {
    await applyPaymentResult(payment.reference, verification.status, Number(payment.amount));
  }

  const fresh = await prisma.payment.findUnique({
    where: { reference },
    include: { booking: { include: { route: true } } },
  });

  res.json({ success: true, payment: fresh });
};
