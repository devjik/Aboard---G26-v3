import { env } from '../../../config/env';
import { AppError } from '../../../utils/AppError';
import { PaymentInitResult, PaymentProvider, PaymentVerificationResult } from '../payment.types';

export class HubtelProvider implements PaymentProvider {
  async initializePayment(
    amount: number,
    currency: string,
    reference: string,
    customerData: { name?: string; phone?: string; email?: string }
  ): Promise<PaymentInitResult> {
    if (env.hubtel.mock) {
      const origin = env.frontendUrl.replace(/\/$/, '');
      return {
        success: true,
        authorizationUrl: `${origin}/booking/success?reference=${encodeURIComponent(reference)}&mock=1`,
        reference,
      };
    }

    if (!env.hubtel.apiId || !env.hubtel.apiKey || !env.hubtel.merchantAccount) {
      throw new AppError(503, 'Payment provider is not configured');
    }

    const origin = env.frontendUrl.replace(/\/$/, '');
    const response = await fetch('https://payproxyapi.hubtel.com/items/initiate', {
      method: 'POST',
      headers: {
        Authorization: `Basic ${Buffer.from(`${env.hubtel.apiId}:${env.hubtel.apiKey}`).toString('base64')}`,
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: JSON.stringify({
        title: 'Onukpa Express Ride',
        totalAmount: amount,
        description: `Bus ticket ${reference}`,
        callbackUrl: env.hubtel.callbackUrl,
        returnUrl: `${origin}/booking/success?reference=${encodeURIComponent(reference)}`,
        merchantAccountNumber: env.hubtel.merchantAccount,
        cancellationUrl: `${origin}/booking/cancelled?reference=${encodeURIComponent(reference)}`,
        clientReference: reference,
        currency,
        metadata: {
          passengerName: customerData?.name,
          passengerPhone: customerData?.phone,
        },
      }),
    });

    const data: any = await response.json().catch(() => ({}));
    if (!response.ok || (data.status && String(data.status).toLowerCase() !== 'success')) {
      return {
        success: false,
        reference,
        error: data.message || 'Hubtel initiation failed',
      };
    }

    return {
      success: true,
      authorizationUrl: data.data?.checkoutUrl || data.data?.checkoutDirectUrl,
      reference,
      providerData: data.data,
    };
  }

  async verifyPayment(reference: string): Promise<PaymentVerificationResult> {
    if (env.hubtel.mock) {
      return {
        success: true,
        status: 'SUCCESS',
        amount: 0,
        currency: 'GHS',
      };
    }

    if (!env.hubtel.apiId || !env.hubtel.apiKey) {
      throw new AppError(503, 'Payment provider is not configured');
    }

    const url = `https://api-txnstatus.hubtel.com/transactions/${encodeURIComponent(
      env.hubtel.merchantAccount
    )}/status?clientReference=${encodeURIComponent(reference)}`;

    const response = await fetch(url, {
      headers: {
        Authorization: `Basic ${Buffer.from(`${env.hubtel.apiId}:${env.hubtel.apiKey}`).toString('base64')}`,
        Accept: 'application/json',
      },
    });

    const data: any = await response.json().catch(() => ({}));
    const statusRaw = String(
      data.data?.status || data.data?.transactionStatus || data.status || ''
    ).toLowerCase();

    let status: 'SUCCESS' | 'FAILED' | 'PENDING' = 'PENDING';
    if (['success', 'paid', '0000'].includes(statusRaw)) status = 'SUCCESS';
    else if (['failed', 'declined', 'cancelled'].includes(statusRaw)) status = 'FAILED';

    return {
      success: status === 'SUCCESS',
      status,
      amount: Number(data.data?.amount || 0),
      currency: data.data?.currency || 'GHS',
      providerData: data.data,
    };
  }
}

/** @deprecated Use HubtelProvider. Kept so older imports keep compiling. */
export class FakeHubtelProvider extends HubtelProvider {}
