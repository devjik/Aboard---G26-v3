import crypto from 'crypto';

export const generateTicketNumber = (): string => {
  const prefix = 'OER';
  const timestamp = Date.now().toString().slice(-6);
  const randomStr = crypto.randomBytes(3).toString('hex').toUpperCase();
  return `${prefix}-${timestamp}-${randomStr}`;
};
