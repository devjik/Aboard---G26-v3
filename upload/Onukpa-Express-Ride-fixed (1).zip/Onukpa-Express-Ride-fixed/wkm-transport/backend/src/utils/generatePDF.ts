import PDFDocument from 'pdfkit';
import fs from 'fs';

export const generateTicketPDF = async (bookingData: any, outputPath: string): Promise<string> => {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({ margin: 50 });
      const stream = fs.createWriteStream(outputPath);
      doc.pipe(stream);

      const passenger =
        bookingData.passengerName ||
        (bookingData.user
          ? `${bookingData.user.firstName} ${bookingData.user.lastName}`
          : 'Passenger');

      doc.fontSize(22).text('Onukpa Express Ride', { align: 'center' });
      doc.moveDown();
      doc.fontSize(16).text(`Ticket: ${bookingData.ticketNumber}`, { align: 'center' });
      doc.moveDown();

      doc.fontSize(13).text('Passenger');
      doc.fontSize(11).text(`Name: ${passenger}`);
      if (bookingData.passengerPhone) doc.text(`Phone: ${bookingData.passengerPhone}`);
      if (bookingData.user?.email) doc.text(`Email: ${bookingData.user.email}`);
      doc.moveDown();

      doc.fontSize(13).text('Trip');
      doc.fontSize(11).text(`Route: ${bookingData.route.departure} → ${bookingData.route.destination}`);
      doc.text(`Departure: ${new Date(bookingData.route.departureTime).toLocaleString('en-GH')}`);
      doc.text(`Arrival: ${new Date(bookingData.route.arrivalTime).toLocaleString('en-GH')}`);
      doc.moveDown();

      doc.fontSize(13).text('Payment');
      doc.fontSize(11).text(`Seats: ${bookingData.numberOfTickets}`);
      doc.text(`Total: GHS ${bookingData.totalAmount}`);
      doc.text(`Status: ${bookingData.status === 'CONFIRMED' ? 'Paid' : bookingData.status}`);

      doc.end();
      stream.on('finish', () => resolve(outputPath));
      stream.on('error', reject);
    } catch (error) {
      reject(error);
    }
  });
};
