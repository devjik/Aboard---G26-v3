import nodemailer from 'nodemailer';
import { env } from '../config/env';
import logger from '../config/logger';

export const sendEmail = async (
  to: string,
  subject: string,
  text: string,
  html?: string,
  attachments?: { filename: string; path: string }[]
) => {
  if (!env.smtp.host) {
    logger.info(`Email skipped (SMTP not configured): ${subject} -> ${to}`);
    return false;
  }

  const transporter = nodemailer.createTransport({
    host: env.smtp.host,
    port: env.smtp.port,
    auth: env.smtp.user ? { user: env.smtp.user, pass: env.smtp.pass } : undefined,
  });

  try {
    const info = await transporter.sendMail({
      from: env.smtp.from,
      to,
      subject,
      text,
      html,
      attachments,
    });
    logger.info(`Email sent: ${info.messageId}`);
    return true;
  } catch (error) {
    logger.error(`Error sending email to ${to}`);
    return false;
  }
};
