import dotenv from 'dotenv';
import Joi from 'joi';
import path from 'path';
import fs from 'fs';

const candidates = [
  path.join(__dirname, '../../.env'),
  path.join(__dirname, '../../../.env'),
];
for (const p of candidates) {
  if (fs.existsSync(p)) dotenv.config({ path: p });
}
dotenv.config();

const envVarsSchema = Joi.object()
  .keys({
    NODE_ENV: Joi.string().valid('production', 'development', 'test').default('development'),
    PORT: Joi.number().default(5000),
    DATABASE_URL: Joi.string().required().description('Postgres DB url'),
    REDIS_URL: Joi.string().allow('').default('redis://localhost:6379'),
    JWT_SECRET: Joi.string().min(16).required().description('JWT secret key'),
    FRONTEND_URL: Joi.string().required().description('Frontend URL for CORS'),
    ADMIN_EMAIL: Joi.string().email().default('admin@onukpaexpress.com'),
    ADMIN_BOOTSTRAP_PASSWORD: Joi.string().allow('').default(''),
    HUBTEL_MOCK: Joi.string().valid('true', 'false', '1', '0').default('false'),
    HUBTEL_MERCHANT_ACCOUNT: Joi.string().allow('').default(''),
    HUBTEL_API_ID: Joi.string().allow('').default(''),
    HUBTEL_API_KEY: Joi.string().allow('').default(''),
    HUBTEL_CALLBACK_URL: Joi.string().allow('').default(''),
    HUBTEL_WEBHOOK_SECRET: Joi.string().allow('').default(''),
    SMTP_HOST: Joi.string().allow('').default(''),
    SMTP_PORT: Joi.number().default(587),
    SMTP_USERNAME: Joi.string().allow('').default(''),
    SMTP_PASSWORD: Joi.string().allow('').default(''),
    EMAIL_FROM: Joi.string().allow('').default('Onukpa Express Ride <noreply@onukpaexpress.com>'),
  })
  .unknown();

const { value: envVars, error } = envVarsSchema
  .prefs({ errors: { label: 'key' } })
  .validate(process.env);

if (error) {
  throw new Error(`Config validation error: ${error.message}`);
}

if (envVars.NODE_ENV === 'production') {
  if (envVars.JWT_SECRET.length < 32 || /changeme|change-me|secret/i.test(envVars.JWT_SECRET)) {
    throw new Error('JWT_SECRET is too weak for production. Use `openssl rand -base64 48`.');
  }
}

const hubtelMock =
  envVars.HUBTEL_MOCK === 'true' ||
  envVars.HUBTEL_MOCK === '1' ||
  (envVars.NODE_ENV !== 'production' && !envVars.HUBTEL_API_KEY);

export const env = {
  env: envVars.NODE_ENV as 'production' | 'development' | 'test',
  port: envVars.PORT as number,
  dbUrl: envVars.DATABASE_URL as string,
  redisUrl: envVars.REDIS_URL as string,
  jwtSecret: envVars.JWT_SECRET as string,
  frontendUrl: envVars.FRONTEND_URL as string,
  adminEmail: envVars.ADMIN_EMAIL as string,
  adminBootstrapPassword: envVars.ADMIN_BOOTSTRAP_PASSWORD as string,
  hubtel: {
    mock: hubtelMock,
    merchantAccount: envVars.HUBTEL_MERCHANT_ACCOUNT as string,
    apiId: envVars.HUBTEL_API_ID as string,
    apiKey: envVars.HUBTEL_API_KEY as string,
    callbackUrl: envVars.HUBTEL_CALLBACK_URL as string,
    webhookSecret: envVars.HUBTEL_WEBHOOK_SECRET as string,
  },
  smtp: {
    host: envVars.SMTP_HOST as string,
    port: envVars.SMTP_PORT as number,
    user: envVars.SMTP_USERNAME as string,
    pass: envVars.SMTP_PASSWORD as string,
    from: envVars.EMAIL_FROM as string,
  },
};
