import Redis from 'ioredis';
import logger from './logger';

const url = process.env.REDIS_URL || 'redis://localhost:6379';

const redisClient = new Redis(url, {
  maxRetriesPerRequest: 1,
  enableReadyCheck: false,
  lazyConnect: true,
});

redisClient.on('error', (err) => {
  logger.error(`Redis error: ${err.message}`);
});

export default redisClient;
