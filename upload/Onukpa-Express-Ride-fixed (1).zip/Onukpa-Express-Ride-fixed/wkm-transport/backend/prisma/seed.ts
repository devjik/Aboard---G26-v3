/**
 * npx prisma db seed
 * (or: npx ts-node prisma/seed.ts)
 */

import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

const corridors = [
  {
    departure: 'Accra (Nkrumah Circle)',
    destination: 'Kumasi (Kejetia)',
    price: 80,
    durationHours: 4,
    times: ['06:00', '09:00', '12:00', '15:00'],
    seats: 45,
  },
  {
    departure: 'Kumasi (Kejetia)',
    destination: 'Accra (Nkrumah Circle)',
    price: 80,
    durationHours: 4,
    times: ['06:00', '09:00', '12:00', '15:00'],
    seats: 45,
  },
  {
    departure: 'Legon (UG Main Gate)',
    destination: 'KNUST (Ayigya)',
    price: 60,
    durationHours: 4,
    times: ['07:00', '11:00', '14:00'],
    seats: 30,
  },
  {
    departure: 'KNUST (Ayigya)',
    destination: 'Legon (UG Main Gate)',
    price: 60,
    durationHours: 4,
    times: ['07:00', '11:00', '14:00'],
    seats: 30,
  },
  {
    departure: 'Accra (Circle)',
    destination: 'Cape Coast (UCC)',
    price: 45,
    durationHours: 3,
    times: ['06:30', '10:00', '13:00'],
    seats: 40,
  },
  {
    departure: 'Cape Coast (UCC)',
    destination: 'Accra (Circle)',
    price: 45,
    durationHours: 3,
    times: ['06:30', '10:00', '13:00'],
    seats: 40,
  },
  {
    departure: 'Accra',
    destination: 'Takoradi',
    price: 70,
    durationHours: 3.5,
    times: ['07:00', '12:00'],
    seats: 45,
  },
  {
    departure: 'Kumasi',
    destination: 'Tamale',
    price: 120,
    durationHours: 7,
    times: ['05:00', '08:00'],
    seats: 45,
  },
];

async function main() {
  const adminEmail = process.env.ADMIN_EMAIL || 'admin@onukpaexpress.com';
  const rawPassword = process.env.ADMIN_BOOTSTRAP_PASSWORD || '';
  const isProd = process.env.NODE_ENV === 'production';
  const passwordPlain =
    rawPassword && !(isProd && /admin@2024/i.test(rawPassword))
      ? rawPassword
      : isProd
        ? null
        : 'OnukpaAdmin1';

  if (!passwordPlain) {
    throw new Error('Refusing to seed the default admin password in production. Set ADMIN_BOOTSTRAP_PASSWORD.');
  }

  const password = await bcrypt.hash(passwordPlain, 12);

  const admin = await prisma.user.upsert({
    where: { email: adminEmail },
    update: { password, role: 'ADMIN' },
    create: {
      email: adminEmail,
      password,
      firstName: 'Onukpa',
      lastName: 'Admin',
      role: 'ADMIN',
    },
  });

  console.log(`Admin ready: ${admin.email}`);
  if (!isProd) console.log(`Dev login password: ${passwordPlain}`);

  const existingFuture = await prisma.route.count({
    where: { departureTime: { gt: new Date() } },
  });
  if (existingFuture > 0) {
    console.log(`Skipping trip seed (${existingFuture} future trips already exist)`);
    return;
  }

  const start = new Date();
  start.setHours(0, 0, 0, 0);
  let created = 0;

  for (let day = 1; day <= 14; day++) {
    for (const c of corridors) {
      for (const t of c.times) {
        const [hh, mm] = t.split(':').map(Number);
        const departureTime = new Date(start);
        departureTime.setDate(start.getDate() + day);
        departureTime.setHours(hh, mm, 0, 0);
        const arrivalTime = new Date(departureTime.getTime() + c.durationHours * 60 * 60 * 1000);
        await prisma.route.create({
          data: {
            departure: c.departure,
            destination: c.destination,
            price: c.price,
            departureTime,
            arrivalTime,
            totalSeats: c.seats,
            availableSeats: c.seats,
            status: 'ACTIVE',
          },
        });
        created += 1;
      }
    }
  }

  console.log(`Created ${created} upcoming trips`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
